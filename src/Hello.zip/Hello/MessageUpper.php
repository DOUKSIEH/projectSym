<?php

namespace App\Hello;

class MessageUpper {


    public function upper(string $s)
    {
        return strtoupper($s);
    }
}